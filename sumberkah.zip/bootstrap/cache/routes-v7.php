<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/broadcasting/auth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::99XFmFD7qfqg5WZh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kK1xvnpWftdtRlS7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uuWyqVbnAScAQAlB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/resetpassword' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.resetpassword',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/changepassword' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.changepassword',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/users/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/users/import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.import',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/users/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/roles/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.roles.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.roles.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.roles.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/roles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.roles.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/permissions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.permissions.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.permissions.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/permissions/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.permissions.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/menupermissions/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menupermissions.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/menupermissions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menupermissions.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menupermissions.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/menu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menu.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menu.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.settings.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.settings.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/settings/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.settings.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/dashboard/dtjo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.dtjo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/dashboard/dtinvoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.dtinvoice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/dashboard/dtmobil' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.dtmobil',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/dashboard/dtdriver' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.dtdriver',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/dashboard/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/tipemobil/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.tipemobil.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/tipemobil' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.tipemobil.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.tipemobil.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/tipemobil/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.tipemobil.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/merkmobil/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.merkmobil.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/merkmobil' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.merkmobil.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.merkmobil.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/merkmobil/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.merkmobil.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/jenismobil/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.jenismobil.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/jenismobil' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.jenismobil.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.jenismobil.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/jenismobil/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.jenismobil.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobil/validasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobil.validasi',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobil/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobil.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobil' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobil.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobil.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobil/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobil.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobilrincian/validasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.validasi',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobilrincian/findmobilrincian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.findmobilrincian',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobilrincian/datatablecekmobilrincian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.datatablecekmobilrincian',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobilrincian/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobilrincian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mobilrincian/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/driver/validasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.driver.validasi',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/driver/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.driver.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/driver' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.driver.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.driver.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/driver/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.driver.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/customer/validasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.customer.validasi',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/customer/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.customer.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/customer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.customer.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.customer.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/customer/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.customer.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/alamatrute/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/alamatrute/select2first' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.select2first',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/alamatrute/select2last' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.select2last',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/alamatrute' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/alamatrute/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/muatan/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.muatan.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/muatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.muatan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.muatan.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/muatan/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.muatan.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/rute/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/rute/validasidelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.validasidelete',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/rute/validasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.validasi',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/rute' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/rute/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/joborder/findkonfirmasijoborder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.findkonfirmasijoborder',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/joborder/findjoborder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.findjoborder',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/Joborder/datatablecekjoborder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.datatablecekjoborder',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/joborder/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/joborder' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/joborder/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/paymentjo/updatesingle' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentjo.updatesingle',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/paymentjo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentjo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentjo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/paymentjo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentjo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/konfirmasijo/findkonfirmasijo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.konfirmasijo.findkonfirmasijo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/konfirmasijo/datatablecekjo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.konfirmasijo.datatablecekjo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/konfirmasijo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.konfirmasijo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.konfirmasijo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/konfirmasijo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.konfirmasijo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/kasbon/validasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.kasbon.validasi',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/kasbon/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.kasbon.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/kasbon' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.kasbon.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.kasbon.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/kasbon/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.kasbon.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/invoice/findinvoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.invoice.findinvoice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/invoice/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.invoice.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.invoice.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.invoice.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/invoice/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.invoice.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/paymentinvoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentinvoice.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentinvoice.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/paymentinvoice/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentinvoice.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/penggajian/findpenggajian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.penggajian.findpenggajian',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/penggajian/select2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.penggajian.select2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/penggajian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.penggajian.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.penggajian.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/penggajian/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.penggajian.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/paymentgaji' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentgaji.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentgaji.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/paymentgaji/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentgaji.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mutasikasbon/ceksaldo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mutasikasbon.ceksaldo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mutasikasbon/datatablecekdriver' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mutasikasbon.datatablecekdriver',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mutasikasbon' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mutasikasbon.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mutasikasbon.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/backend/mutasikasbon/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mutasikasbon.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/backend/(?|users/([^/]++)(?|(*:36)|/edit(*:48)|(*:55))|r(?|oles/([^/]++)(?|(*:83)|/edit(*:95)|(*:102))|ute/([^/]++)(?|(*:126)|/edit(*:139)|(*:147)))|p(?|e(?|rmissions/([^/]++)(?|(*:186)|/edit(*:199)|(*:207))|nggajian/([^/]++)(?|(*:236)|/edit(*:249)|(*:257)))|ayment(?|jo/([^/]++)(?|/(?|pdf(*:297)|edit(*:309))|(*:318))|invoice/([^/]++)(?|(*:346)|/edit(*:359)|(*:367))|gaji/([^/]++)(?|(*:392)|/edit(*:405)|(*:413))))|m(?|e(?|nu(?|permissions/([^/]++)(?|(*:460))|/(?|([^/]++)(?|/edit(*:489)|(*:497))|changeHierarchy(*:521)))|rkmobil/([^/]++)(?|(*:550)|/edit(*:563)|(*:571)))|obil(?|/([^/]++)(?|(*:600)|/edit(*:613)|(*:621))|rincian/([^/]++)(?|(*:649)|/edit(*:662)|(*:670)))|u(?|atan/([^/]++)(?|(*:700)|/edit(*:713)|(*:721))|tasikasbon/([^/]++)(?|(*:752)|/edit(*:765)|(*:773))))|settings/([^/]++)(?|(*:804)|/edit(*:817)|(*:825))|d(?|ashboard/([^/]++)(?|(*:858)|/edit(*:871)|(*:879))|river/([^/]++)(?|(*:905)|/edit(*:918)|(*:926)))|tipemobil/([^/]++)(?|(*:957)|/edit(*:970)|(*:978))|j(?|enismobil/([^/]++)(?|(*:1012)|/edit(*:1026)|(*:1035))|oborder/([^/]++)(?|(*:1064)|/edit(*:1078)|(*:1087)))|customer/([^/]++)(?|(*:1118)|/edit(*:1132)|(*:1141))|alamatrute/([^/]++)(?|(*:1173)|/edit(*:1187)|(*:1196))|k(?|onfirmasijo/([^/]++)(?|(*:1233)|/edit(*:1247)|(*:1256))|asbon/([^/]++)(?|(*:1283)|/edit(*:1297)|(*:1306)))|invoice/([^/]++)(?|(*:1336)|/edit(*:1350)|(*:1359))))/?$}sDu',
    ),
    3 => 
    array (
      36 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.show',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      48 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.edit',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      55 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.update',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.users.destroy',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      83 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.roles.show',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      95 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.roles.edit',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      102 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.roles.update',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.roles.destroy',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      126 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.show',
          ),
          1 => 
          array (
            0 => 'rute',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      139 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.edit',
          ),
          1 => 
          array (
            0 => 'rute',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.update',
          ),
          1 => 
          array (
            0 => 'rute',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.rute.destroy',
          ),
          1 => 
          array (
            0 => 'rute',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      186 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.permissions.show',
          ),
          1 => 
          array (
            0 => 'permission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      199 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.permissions.edit',
          ),
          1 => 
          array (
            0 => 'permission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      207 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.permissions.update',
          ),
          1 => 
          array (
            0 => 'permission',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.permissions.destroy',
          ),
          1 => 
          array (
            0 => 'permission',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      236 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.penggajian.show',
          ),
          1 => 
          array (
            0 => 'penggajian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.penggajian.edit',
          ),
          1 => 
          array (
            0 => 'penggajian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      257 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.penggajian.update',
          ),
          1 => 
          array (
            0 => 'penggajian',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.penggajian.destroy',
          ),
          1 => 
          array (
            0 => 'penggajian',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      297 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentjo.pdf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      309 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentjo.edit',
          ),
          1 => 
          array (
            0 => 'paymentjo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      318 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentjo.show',
          ),
          1 => 
          array (
            0 => 'paymentjo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentjo.update',
          ),
          1 => 
          array (
            0 => 'paymentjo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentjo.destroy',
          ),
          1 => 
          array (
            0 => 'paymentjo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      346 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentinvoice.show',
          ),
          1 => 
          array (
            0 => 'paymentinvoice',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      359 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentinvoice.edit',
          ),
          1 => 
          array (
            0 => 'paymentinvoice',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      367 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentinvoice.update',
          ),
          1 => 
          array (
            0 => 'paymentinvoice',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentinvoice.destroy',
          ),
          1 => 
          array (
            0 => 'paymentinvoice',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      392 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentgaji.show',
          ),
          1 => 
          array (
            0 => 'paymentgaji',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      405 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentgaji.edit',
          ),
          1 => 
          array (
            0 => 'paymentgaji',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      413 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentgaji.update',
          ),
          1 => 
          array (
            0 => 'paymentgaji',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.paymentgaji.destroy',
          ),
          1 => 
          array (
            0 => 'paymentgaji',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      460 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menupermissions.update',
          ),
          1 => 
          array (
            0 => 'menupermission',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menupermissions.destroy',
          ),
          1 => 
          array (
            0 => 'menupermission',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      489 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menu.edit',
          ),
          1 => 
          array (
            0 => 'menu',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      497 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menu.update',
          ),
          1 => 
          array (
            0 => 'menu',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menu.destroy',
          ),
          1 => 
          array (
            0 => 'menu',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      521 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.menu.changeHierarchy',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      550 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.merkmobil.show',
          ),
          1 => 
          array (
            0 => 'merkmobil',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      563 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.merkmobil.edit',
          ),
          1 => 
          array (
            0 => 'merkmobil',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      571 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.merkmobil.update',
          ),
          1 => 
          array (
            0 => 'merkmobil',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.merkmobil.destroy',
          ),
          1 => 
          array (
            0 => 'merkmobil',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      600 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobil.show',
          ),
          1 => 
          array (
            0 => 'mobil',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      613 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobil.edit',
          ),
          1 => 
          array (
            0 => 'mobil',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      621 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobil.update',
          ),
          1 => 
          array (
            0 => 'mobil',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobil.destroy',
          ),
          1 => 
          array (
            0 => 'mobil',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      649 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.show',
          ),
          1 => 
          array (
            0 => 'mobilrincian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      662 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.edit',
          ),
          1 => 
          array (
            0 => 'mobilrincian',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      670 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.update',
          ),
          1 => 
          array (
            0 => 'mobilrincian',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mobilrincian.destroy',
          ),
          1 => 
          array (
            0 => 'mobilrincian',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      700 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.muatan.show',
          ),
          1 => 
          array (
            0 => 'muatan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      713 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.muatan.edit',
          ),
          1 => 
          array (
            0 => 'muatan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      721 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.muatan.update',
          ),
          1 => 
          array (
            0 => 'muatan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.muatan.destroy',
          ),
          1 => 
          array (
            0 => 'muatan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      752 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mutasikasbon.show',
          ),
          1 => 
          array (
            0 => 'mutasikasbon',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      765 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mutasikasbon.edit',
          ),
          1 => 
          array (
            0 => 'mutasikasbon',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      773 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mutasikasbon.update',
          ),
          1 => 
          array (
            0 => 'mutasikasbon',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.mutasikasbon.destroy',
          ),
          1 => 
          array (
            0 => 'mutasikasbon',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      804 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.settings.show',
          ),
          1 => 
          array (
            0 => 'setting',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      817 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.settings.edit',
          ),
          1 => 
          array (
            0 => 'setting',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      825 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.settings.update',
          ),
          1 => 
          array (
            0 => 'setting',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.settings.destroy',
          ),
          1 => 
          array (
            0 => 'setting',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      858 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.show',
          ),
          1 => 
          array (
            0 => 'dashboard',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      871 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.edit',
          ),
          1 => 
          array (
            0 => 'dashboard',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      879 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.update',
          ),
          1 => 
          array (
            0 => 'dashboard',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.dashboard.destroy',
          ),
          1 => 
          array (
            0 => 'dashboard',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      905 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.driver.show',
          ),
          1 => 
          array (
            0 => 'driver',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      918 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.driver.edit',
          ),
          1 => 
          array (
            0 => 'driver',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      926 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.driver.update',
          ),
          1 => 
          array (
            0 => 'driver',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.driver.destroy',
          ),
          1 => 
          array (
            0 => 'driver',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      957 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.tipemobil.show',
          ),
          1 => 
          array (
            0 => 'tipemobil',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      970 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.tipemobil.edit',
          ),
          1 => 
          array (
            0 => 'tipemobil',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      978 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.tipemobil.update',
          ),
          1 => 
          array (
            0 => 'tipemobil',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.tipemobil.destroy',
          ),
          1 => 
          array (
            0 => 'tipemobil',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1012 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.jenismobil.show',
          ),
          1 => 
          array (
            0 => 'jenismobil',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1026 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.jenismobil.edit',
          ),
          1 => 
          array (
            0 => 'jenismobil',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1035 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.jenismobil.update',
          ),
          1 => 
          array (
            0 => 'jenismobil',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.jenismobil.destroy',
          ),
          1 => 
          array (
            0 => 'jenismobil',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1064 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.show',
          ),
          1 => 
          array (
            0 => 'joborder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1078 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.edit',
          ),
          1 => 
          array (
            0 => 'joborder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1087 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.update',
          ),
          1 => 
          array (
            0 => 'joborder',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.joborder.destroy',
          ),
          1 => 
          array (
            0 => 'joborder',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1118 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.customer.show',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.customer.edit',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1141 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.customer.update',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.customer.destroy',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.show',
          ),
          1 => 
          array (
            0 => 'alamatrute',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1187 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.edit',
          ),
          1 => 
          array (
            0 => 'alamatrute',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1196 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.update',
          ),
          1 => 
          array (
            0 => 'alamatrute',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.alamatrute.destroy',
          ),
          1 => 
          array (
            0 => 'alamatrute',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1233 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.konfirmasijo.show',
          ),
          1 => 
          array (
            0 => 'konfirmasijo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1247 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.konfirmasijo.edit',
          ),
          1 => 
          array (
            0 => 'konfirmasijo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1256 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.konfirmasijo.update',
          ),
          1 => 
          array (
            0 => 'konfirmasijo',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.konfirmasijo.destroy',
          ),
          1 => 
          array (
            0 => 'konfirmasijo',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1283 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.kasbon.show',
          ),
          1 => 
          array (
            0 => 'kasbon',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1297 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.kasbon.edit',
          ),
          1 => 
          array (
            0 => 'kasbon',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1306 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.kasbon.update',
          ),
          1 => 
          array (
            0 => 'kasbon',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.kasbon.destroy',
          ),
          1 => 
          array (
            0 => 'kasbon',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1336 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.invoice.show',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1350 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.invoice.edit',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1359 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'backend.invoice.update',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'backend.invoice.destroy',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::99XFmFD7qfqg5WZh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'broadcasting/auth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'controller' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
        ),
        'as' => 'generated::99XFmFD7qfqg5WZh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kK1xvnpWftdtRlS7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003910000000000000000";}";s:4:"hash";s:44:"RGtON51xwyElQw4H5fhgh9xsLn/VxqCJHQTqtLArwqU=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::kK1xvnpWftdtRlS7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uuWyqVbnAScAQAlB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:281:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:63:"function () {
    return \\redirect()->route(\'backend.login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003930000000000000000";}";s:4:"hash";s:44:"KMaHqkbMuPGPMUCQOCiTMQ/fF/4Su64dxp2DIWYSsZg=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uuWyqVbnAScAQAlB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'as' => 'backend.',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'as' => 'backend.login',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.resetpassword' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/resetpassword',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@resetpassword',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@resetpassword',
        'as' => 'backend.users.resetpassword',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.changepassword' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/changepassword',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@changepassword',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@changepassword',
        'as' => 'backend.users.changepassword',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/users/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@select2',
        'as' => 'backend.users.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.import' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/users/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@import',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@import',
        'as' => 'backend.users.import',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.users.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/users/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.users.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.users.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.users.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/users/{user}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.users.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.users.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.users.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.users.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.roles.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/roles/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\RoleController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\RoleController@select2',
        'as' => 'backend.roles.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.roles.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.roles.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\RoleController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\RoleController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.roles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/roles/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.roles.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\RoleController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\RoleController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.roles.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.roles.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\RoleController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\RoleController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.roles.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/roles/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.roles.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\RoleController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\RoleController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.roles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/roles/{role}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.roles.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\RoleController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\RoleController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.roles.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/roles/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.roles.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\RoleController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\RoleController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.roles.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/roles/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.roles.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\RoleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\RoleController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.permissions.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/permissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.permissions.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\PermissionController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\PermissionController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.permissions.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/permissions/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.permissions.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\PermissionController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\PermissionController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.permissions.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/permissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.permissions.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\PermissionController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\PermissionController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.permissions.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/permissions/{permission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.permissions.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\PermissionController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\PermissionController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.permissions.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/permissions/{permission}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.permissions.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\PermissionController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\PermissionController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.permissions.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/permissions/{permission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.permissions.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\PermissionController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\PermissionController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.permissions.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/permissions/{permission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.permissions.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\PermissionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\PermissionController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menupermissions.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/menupermissions/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@select2',
        'as' => 'backend.menupermissions.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menupermissions.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/menupermissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.menupermissions.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menupermissions.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/menupermissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.menupermissions.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menupermissions.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/menupermissions/{menupermission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.menupermissions.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menupermissions.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/menupermissions/{menupermission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.menupermissions.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuPermissionController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menu.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.menu.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menu.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/menu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.menu.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menu.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/menu/{menu}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.menu.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menu.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/menu/{menu}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.menu.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menu.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/menu/{menu}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.menu.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.menu.changeHierarchy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/menu/changeHierarchy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@changeHierarchy',
        'controller' => 'App\\Http\\Controllers\\Backend\\MenuManagerController@changeHierarchy',
        'as' => 'backend.menu.changeHierarchy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.settings.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.settings.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\SettingsController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\SettingsController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.settings.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/settings/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.settings.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\SettingsController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\SettingsController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.settings.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.settings.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\SettingsController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\SettingsController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.settings.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/settings/{setting}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.settings.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\SettingsController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\SettingsController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.settings.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/settings/{setting}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.settings.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\SettingsController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\SettingsController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.settings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/settings/{setting}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.settings.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\SettingsController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\SettingsController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.settings.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/settings/{setting}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.settings.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\SettingsController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\SettingsController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.dtjo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/dashboard/dtjo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@dtjo',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@dtjo',
        'as' => 'backend.dashboard.dtjo',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.dtinvoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/dashboard/dtinvoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@dtinvoice',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@dtinvoice',
        'as' => 'backend.dashboard.dtinvoice',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.dtmobil' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/dashboard/dtmobil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@dtmobil',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@dtmobil',
        'as' => 'backend.dashboard.dtmobil',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.dtdriver' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/dashboard/dtdriver',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@dtdriver',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@dtdriver',
        'as' => 'backend.dashboard.dtdriver',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.dashboard.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/dashboard/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.dashboard.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.dashboard.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/dashboard/{dashboard}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.dashboard.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/dashboard/{dashboard}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.dashboard.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/dashboard/{dashboard}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.dashboard.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.dashboard.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/dashboard/{dashboard}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.dashboard.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\DashboardController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\DashboardController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.tipemobil.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/tipemobil/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\TipemobilController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\TipemobilController@select2',
        'as' => 'backend.tipemobil.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.tipemobil.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/tipemobil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.tipemobil.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\TipemobilController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\TipemobilController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.tipemobil.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/tipemobil/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.tipemobil.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\TipemobilController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\TipemobilController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.tipemobil.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/tipemobil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.tipemobil.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\TipemobilController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\TipemobilController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.tipemobil.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/tipemobil/{tipemobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.tipemobil.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\TipemobilController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\TipemobilController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.tipemobil.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/tipemobil/{tipemobil}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.tipemobil.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\TipemobilController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\TipemobilController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.tipemobil.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/tipemobil/{tipemobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.tipemobil.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\TipemobilController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\TipemobilController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.tipemobil.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/tipemobil/{tipemobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.tipemobil.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\TipemobilController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\TipemobilController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.merkmobil.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/merkmobil/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@select2',
        'as' => 'backend.merkmobil.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.merkmobil.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/merkmobil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.merkmobil.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.merkmobil.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/merkmobil/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.merkmobil.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.merkmobil.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/merkmobil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.merkmobil.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.merkmobil.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/merkmobil/{merkmobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.merkmobil.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.merkmobil.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/merkmobil/{merkmobil}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.merkmobil.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.merkmobil.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/merkmobil/{merkmobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.merkmobil.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.merkmobil.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/merkmobil/{merkmobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.merkmobil.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\MerkmobilController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.jenismobil.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/jenismobil/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\JenismobilController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\JenismobilController@select2',
        'as' => 'backend.jenismobil.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.jenismobil.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/jenismobil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.jenismobil.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\JenismobilController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\JenismobilController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.jenismobil.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/jenismobil/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.jenismobil.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\JenismobilController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\JenismobilController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.jenismobil.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/jenismobil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.jenismobil.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\JenismobilController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\JenismobilController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.jenismobil.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/jenismobil/{jenismobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.jenismobil.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\JenismobilController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\JenismobilController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.jenismobil.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/jenismobil/{jenismobil}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.jenismobil.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\JenismobilController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\JenismobilController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.jenismobil.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/jenismobil/{jenismobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.jenismobil.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\JenismobilController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\JenismobilController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.jenismobil.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/jenismobil/{jenismobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.jenismobil.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\JenismobilController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\JenismobilController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobil.validasi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'backend/mobil/validasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilController@validasi',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilController@validasi',
        'as' => 'backend.mobil.validasi',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobil.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobil/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilController@select2',
        'as' => 'backend.mobil.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobil.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobil.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobil.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobil/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobil.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobil.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/mobil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobil.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobil.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobil/{mobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobil.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobil.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobil/{mobil}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobil.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobil.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/mobil/{mobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobil.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobil.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/mobil/{mobil}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobil.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.validasi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'backend/mobilrincian/validasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@validasi',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@validasi',
        'as' => 'backend.mobilrincian.validasi',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.findmobilrincian' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobilrincian/findmobilrincian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@findmobilrincian',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@findmobilrincian',
        'as' => 'backend.mobilrincian.findmobilrincian',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.datatablecekmobilrincian' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobilrincian/datatablecekmobilrincian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@datatablecekmobilrincian',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@datatablecekmobilrincian',
        'as' => 'backend.mobilrincian.datatablecekmobilrincian',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobilrincian/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@select2',
        'as' => 'backend.mobilrincian.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobilrincian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobilrincian.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobilrincian/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobilrincian.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/mobilrincian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobilrincian.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobilrincian/{mobilrincian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobilrincian.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mobilrincian/{mobilrincian}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobilrincian.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/mobilrincian/{mobilrincian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobilrincian.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mobilrincian.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/mobilrincian/{mobilrincian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mobilrincian.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\MobilRincianController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.driver.validasi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'backend/driver/validasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\DriverController@validasi',
        'controller' => 'App\\Http\\Controllers\\Backend\\DriverController@validasi',
        'as' => 'backend.driver.validasi',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.driver.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/driver/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\DriverController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\DriverController@select2',
        'as' => 'backend.driver.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.driver.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/driver',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.driver.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\DriverController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\DriverController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.driver.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/driver/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.driver.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\DriverController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\DriverController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.driver.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/driver',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.driver.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\DriverController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\DriverController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.driver.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/driver/{driver}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.driver.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\DriverController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\DriverController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.driver.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/driver/{driver}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.driver.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\DriverController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\DriverController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.driver.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/driver/{driver}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.driver.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\DriverController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\DriverController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.driver.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/driver/{driver}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.driver.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\DriverController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\DriverController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.customer.validasi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'backend/customer/validasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\CustomerController@validasi',
        'controller' => 'App\\Http\\Controllers\\Backend\\CustomerController@validasi',
        'as' => 'backend.customer.validasi',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.customer.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/customer/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\CustomerController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\CustomerController@select2',
        'as' => 'backend.customer.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.customer.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/customer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.customer.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\CustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\CustomerController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.customer.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/customer/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.customer.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\CustomerController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\CustomerController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.customer.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/customer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.customer.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\CustomerController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\CustomerController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.customer.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/customer/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.customer.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\CustomerController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\CustomerController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.customer.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/customer/{customer}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.customer.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\CustomerController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\CustomerController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.customer.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/customer/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.customer.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\CustomerController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\CustomerController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.customer.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/customer/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.customer.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\CustomerController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\CustomerController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/alamatrute/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@select2',
        'as' => 'backend.alamatrute.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.select2first' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/alamatrute/select2first',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@select2first',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@select2first',
        'as' => 'backend.alamatrute.select2first',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.select2last' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/alamatrute/select2last',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@select2last',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@select2last',
        'as' => 'backend.alamatrute.select2last',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/alamatrute',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.alamatrute.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/alamatrute/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.alamatrute.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/alamatrute',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.alamatrute.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/alamatrute/{alamatrute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.alamatrute.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/alamatrute/{alamatrute}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.alamatrute.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/alamatrute/{alamatrute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.alamatrute.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.alamatrute.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/alamatrute/{alamatrute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.alamatrute.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\AlamatruteController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.muatan.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/muatan/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MuatanController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\MuatanController@select2',
        'as' => 'backend.muatan.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.muatan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/muatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.muatan.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\MuatanController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\MuatanController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.muatan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/muatan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.muatan.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\MuatanController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\MuatanController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.muatan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/muatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.muatan.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\MuatanController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\MuatanController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.muatan.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/muatan/{muatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.muatan.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\MuatanController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\MuatanController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.muatan.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/muatan/{muatan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.muatan.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\MuatanController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\MuatanController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.muatan.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/muatan/{muatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.muatan.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\MuatanController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\MuatanController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.muatan.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/muatan/{muatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.muatan.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\MuatanController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\MuatanController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/rute/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@select2',
        'as' => 'backend.rute.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.validasidelete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'backend/rute/validasidelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@validasidelete',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@validasidelete',
        'as' => 'backend.rute.validasidelete',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.validasi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'backend/rute/validasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@validasi',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@validasi',
        'as' => 'backend.rute.validasi',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/rute',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.rute.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/rute/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.rute.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/rute',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.rute.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/rute/{rute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.rute.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/rute/{rute}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.rute.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/rute/{rute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.rute.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.rute.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/rute/{rute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.rute.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\RuteController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\RuteController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.findkonfirmasijoborder' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/joborder/findkonfirmasijoborder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@findkonfirmasijoborder',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@findkonfirmasijoborder',
        'as' => 'backend.joborder.findkonfirmasijoborder',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.findjoborder' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/joborder/findjoborder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@findjoborder',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@findjoborder',
        'as' => 'backend.joborder.findjoborder',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.datatablecekjoborder' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/Joborder/datatablecekjoborder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@datatablecekjoborder',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@datatablecekjoborder',
        'as' => 'backend.joborder.datatablecekjoborder',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/joborder/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@select2',
        'as' => 'backend.joborder.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/joborder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.joborder.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/joborder/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.joborder.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/joborder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.joborder.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/joborder/{joborder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.joborder.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/joborder/{joborder}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.joborder.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/joborder/{joborder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.joborder.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.joborder.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/joborder/{joborder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.joborder.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\JoborderController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\JoborderController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentjo.updatesingle' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'backend/paymentjo/updatesingle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@updatesingle',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@updatesingle',
        'as' => 'backend.paymentjo.updatesingle',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentjo.pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentjo/{id}/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@pdf',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@pdf',
        'as' => 'backend.paymentjo.pdf',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentjo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentjo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentjo.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentjo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentjo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentjo.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentjo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/paymentjo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentjo.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentjo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentjo/{paymentjo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentjo.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentjo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentjo/{paymentjo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentjo.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentjo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/paymentjo/{paymentjo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentjo.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentjo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/paymentjo/{paymentjo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentjo.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentJoController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.konfirmasijo.findkonfirmasijo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/konfirmasijo/findkonfirmasijo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@findkonfirmasijo',
        'controller' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@findkonfirmasijo',
        'as' => 'backend.konfirmasijo.findkonfirmasijo',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.konfirmasijo.datatablecekjo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/konfirmasijo/datatablecekjo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@datatablecekjo',
        'controller' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@datatablecekjo',
        'as' => 'backend.konfirmasijo.datatablecekjo',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.konfirmasijo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/konfirmasijo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.konfirmasijo.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.konfirmasijo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/konfirmasijo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.konfirmasijo.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.konfirmasijo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/konfirmasijo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.konfirmasijo.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.konfirmasijo.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/konfirmasijo/{konfirmasijo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.konfirmasijo.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.konfirmasijo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/konfirmasijo/{konfirmasijo}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.konfirmasijo.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.konfirmasijo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/konfirmasijo/{konfirmasijo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.konfirmasijo.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.konfirmasijo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/konfirmasijo/{konfirmasijo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.konfirmasijo.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\KonfirmasiJoController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.kasbon.validasi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'backend/kasbon/validasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\KasbonController@validasi',
        'controller' => 'App\\Http\\Controllers\\Backend\\KasbonController@validasi',
        'as' => 'backend.kasbon.validasi',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.kasbon.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/kasbon/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\KasbonController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\KasbonController@select2',
        'as' => 'backend.kasbon.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.kasbon.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/kasbon',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.kasbon.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\KasbonController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\KasbonController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.kasbon.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/kasbon/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.kasbon.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\KasbonController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\KasbonController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.kasbon.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/kasbon',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.kasbon.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\KasbonController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\KasbonController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.kasbon.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/kasbon/{kasbon}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.kasbon.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\KasbonController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\KasbonController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.kasbon.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/kasbon/{kasbon}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.kasbon.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\KasbonController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\KasbonController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.kasbon.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/kasbon/{kasbon}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.kasbon.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\KasbonController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\KasbonController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.kasbon.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/kasbon/{kasbon}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.kasbon.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\KasbonController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\KasbonController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.invoice.findinvoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/invoice/findinvoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\InvoiceController@findinvoice',
        'controller' => 'App\\Http\\Controllers\\Backend\\InvoiceController@findinvoice',
        'as' => 'backend.invoice.findinvoice',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.invoice.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/invoice/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\InvoiceController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\InvoiceController@select2',
        'as' => 'backend.invoice.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.invoice.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.invoice.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\InvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\InvoiceController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.invoice.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/invoice/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.invoice.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\InvoiceController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\InvoiceController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.invoice.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.invoice.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\InvoiceController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\InvoiceController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.invoice.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/invoice/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.invoice.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\InvoiceController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\InvoiceController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.invoice.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/invoice/{invoice}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.invoice.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\InvoiceController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\InvoiceController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.invoice.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/invoice/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.invoice.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\InvoiceController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\InvoiceController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.invoice.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/invoice/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.invoice.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\InvoiceController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\InvoiceController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentinvoice.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentinvoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentinvoice.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentinvoice.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentinvoice/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentinvoice.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentinvoice.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/paymentinvoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentinvoice.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentinvoice.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentinvoice/{paymentinvoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentinvoice.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentinvoice.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentinvoice/{paymentinvoice}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentinvoice.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentinvoice.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/paymentinvoice/{paymentinvoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentinvoice.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentinvoice.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/paymentinvoice/{paymentinvoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentinvoice.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentInvoiceController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.penggajian.findpenggajian' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/penggajian/findpenggajian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\PenggajianController@findpenggajian',
        'controller' => 'App\\Http\\Controllers\\Backend\\PenggajianController@findpenggajian',
        'as' => 'backend.penggajian.findpenggajian',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.penggajian.select2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/penggajian/select2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\PenggajianController@select2',
        'controller' => 'App\\Http\\Controllers\\Backend\\PenggajianController@select2',
        'as' => 'backend.penggajian.select2',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.penggajian.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/penggajian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.penggajian.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\PenggajianController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\PenggajianController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.penggajian.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/penggajian/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.penggajian.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\PenggajianController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\PenggajianController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.penggajian.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/penggajian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.penggajian.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\PenggajianController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\PenggajianController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.penggajian.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/penggajian/{penggajian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.penggajian.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\PenggajianController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\PenggajianController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.penggajian.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/penggajian/{penggajian}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.penggajian.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\PenggajianController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\PenggajianController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.penggajian.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/penggajian/{penggajian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.penggajian.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\PenggajianController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\PenggajianController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.penggajian.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/penggajian/{penggajian}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.penggajian.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\PenggajianController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\PenggajianController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentgaji.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentgaji',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentgaji.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentgaji.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentgaji/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentgaji.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentgaji.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/paymentgaji',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentgaji.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentgaji.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentgaji/{paymentgaji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentgaji.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentgaji.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/paymentgaji/{paymentgaji}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentgaji.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentgaji.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/paymentgaji/{paymentgaji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentgaji.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.paymentgaji.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/paymentgaji/{paymentgaji}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.paymentgaji.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\PaymentGajiController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mutasikasbon.ceksaldo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mutasikasbon/ceksaldo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@ceksaldo',
        'controller' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@ceksaldo',
        'as' => 'backend.mutasikasbon.ceksaldo',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mutasikasbon.datatablecekdriver' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mutasikasbon/datatablecekdriver',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'uses' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@datatablecekdriver',
        'controller' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@datatablecekdriver',
        'as' => 'backend.mutasikasbon.datatablecekdriver',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mutasikasbon.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mutasikasbon',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mutasikasbon.index',
        'uses' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@index',
        'controller' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@index',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mutasikasbon.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mutasikasbon/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mutasikasbon.create',
        'uses' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@create',
        'controller' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@create',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mutasikasbon.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'backend/mutasikasbon',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mutasikasbon.store',
        'uses' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@store',
        'controller' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@store',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mutasikasbon.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mutasikasbon/{mutasikasbon}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mutasikasbon.show',
        'uses' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@show',
        'controller' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@show',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mutasikasbon.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'backend/mutasikasbon/{mutasikasbon}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mutasikasbon.edit',
        'uses' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@edit',
        'controller' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@edit',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mutasikasbon.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'backend/mutasikasbon/{mutasikasbon}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mutasikasbon.update',
        'uses' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@update',
        'controller' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@update',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'backend.mutasikasbon.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'backend/mutasikasbon/{mutasikasbon}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:henmus',
        ),
        'as' => 'backend.mutasikasbon.destroy',
        'uses' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@destroy',
        'controller' => 'App\\Http\\Controllers\\Backend\\MutasikasbonController@destroy',
        'namespace' => NULL,
        'prefix' => '/backend',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
