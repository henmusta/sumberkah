<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="float-end">
                    <a onclick="printDiv('printableArea')" class="btn btn-success me-1"><i class="fa fa-print"></i></a>
                    <a onclick="window.history.back();" class="btn btn-primary w-md">Kembali</a>
                </div>
            </div>
            <div class="card-body" id="printableArea">
                <div class="invoice-title text-center">
                    <h2 class="main-content-label mb-1">Invoice</h2>
                    <div class="mb-4">
                           <img  src="<?php echo e(URL::to('storage/images/logo/'.Setting::get_setting()->icon)); ?>" alt="logo" height="50">
                    </div>
                    <div class="text-muted">
                    </div>
                </div>



                <div class="row" style="padding-top:10px;">
                    <div class="col-12">
                        <table>
                            <tr>
                                <td style="width: 300px; ">Customer</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td style="font-weight:bold"><?php echo e($data['invoice']['customer']['name'] ?? ''); ?></td>
                            </tr>
                            <tr>
                                <td style="width: 300px; ">Nomor Invoice</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td  style="font-weight:bold"><?php echo e($data['invoice']['kode_invoice'] ?? ''); ?></td>
                            </tr>
                            <tr>
                                <td style="width: 300px; ">Tanggal Invoice</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td  style="font-weight:bold">    <?php echo e(\Carbon\Carbon::parse($data['invoice']['tgl_invoice'])->format('d-m-Y')); ?></td>
                            </tr>
                            <tr>
                                <td style="width: 300px; ">Batas Pembayaran</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td  style="font-weight:bold"><?php echo e($data['invoice']['payment_hari'] ?? ''); ?> Hari (<?php echo e(\Carbon\Carbon::parse($data['invoice']['tgl_jatuh_tempo'])->format('d-m-Y')); ?>)</td>
                            </tr>
                            <tr>
                                <td style="width: 300px; ">Muatan</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td  style="font-weight:bold"><?php echo e($data['invoice']['joborder'][0]['muatan']['name'] ?? ''); ?></td>
                            </tr>
                            <?php if( $data['invoice']['status_payment'] == '2'): ?>
                                <?php ($class =  'bg-success'); ?>
                                <?php ($text =  'Lunas'); ?>
                            <?php elseif( $data['invoice']['status_payment'] == '1'): ?>
                                <?php ($class =  'bg-warning'); ?>
                                <?php ($text =  'Progress Payment'); ?>
                            <?php else: ?>
                                <?php ($class = 'bg-danger'); ?>
                                <?php ($text =  'Belum Bayar'); ?>
                            <?php endif; ?>

                            <tr>
                                <td style="width: 300px;">Status Pembayaran</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td  style="font-weight:bold"><span class="badge bg-pill <?php echo e($class); ?>"><?php echo e($text); ?></span> </td>
                            </tr>
                            <tr>
                                <td style="width: 300px; ">Keterangan</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td  style="font-weight:bold"><?php echo e($data['invoice']['keterangan_invoice'] ?? ''); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="row" style="padding-top:50px;">
                    <h6 class="main-content-label mb-1">Pembayaran</h6>
                    <div class="col-12">
                        <div class="table-responsive">
                            <table id="Datatable" class="table table-bordered border-bottom w-100" style="width:100%">
                                <thead>
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th>Kode Joborder</th>
                                        <th>Tanggal Muat</th>
                                        <th>Tanggal Bongkar</th>
                                        <th>Nomor Polisi</th>
                                        <th>Dari</th>
                                        <th>Ke</th>
                                        <?php ($colspan_1 = '8'); ?>
                                        <?php ($colspan_2 = '9'); ?>
                                        <?php if($data['invoice']['joborder'][0]['rute']['ritase_tonase'] != 'Ritase'): ?>
                                        <th>Total Muatan</th>
                                            <?php ($colspan_1 = '9'); ?>
                                            <?php ($colspan_2 = '10'); ?>
                                        <?php endif; ?>
                                        <th>Harga</th>
                                        <th>Total</th>
                                      </tr>
                                </thead>
                                <tbody>
                                    <?php ($no=1); ?>;
                                    <?php $__currentLoopData = $data['konfirmasijo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td width="2%" class="text-center"><?php echo e($no++); ?></td>
                                            <td><?php echo e($val->kode_joborder); ?></td>
                                            <td><?php echo e($val->tgl_muat); ?></td>
                                            <td><?php echo e($val->tgl_bongkar); ?></td>
                                            <td><?php echo e($val->joborder['mobil']['nomor_plat']); ?></td>
                                            <td><?php echo e($val->joborder['ruteawal']['name']); ?></td>
                                            <td><?php echo e($val->joborder['ruteakhir']['name']); ?></td>
                                            <?php if($val->joborder['rute']['ritase_tonase'] != 'Ritase'): ?>
                                                 <td><?php echo e($val->berat_muatan); ?></td>
                                            <?php endif; ?>
                                            <td class="text-end"> Rp. <?php echo e(number_format($val->joborder['rute']['harga'],0,',','.')); ?></td>
                                            <td class="text-end"> Rp. <?php echo e(number_format($val->total_harga,0,',','.')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <?php if($data['invoice']['tambahan_potongan'] != 'None'): ?>
                                    <tr>
                                        <th class="text-end" colspan="9"><?php echo e($data['invoice']['tambahan_potongan']); ?> Harga</th>
                                        <th class="text-end">Rp. <?php echo e(number_format($data['invoice']['nominal_tambahan_potongan'],0,',','.')); ?></th>
                                    </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <th class="text-end" colspan="<?php echo e($colspan_1); ?>">Total</th>
                                        <th class="text-end">Rp. <?php echo e(number_format($data['konfirmasijo']->SUM('total_harga'),0,',','.')); ?></th>
                                    </tr>
                                    <tr>
                                        <th class="text-end" colspan="<?php echo e($colspan_1); ?>">PPN 11%</th>
                                        <th class="text-end">Rp. <?php echo e(number_format($data['invoice']['nominal_ppn'],0,',','.')); ?></th>
                                    </tr>
                                    <tr>
                                        <th class="text-end" colspan="<?php echo e($colspan_1); ?>">Grand Total</th>
                                        <th class="text-end">Rp. <?php echo e(number_format($data['invoice']['total_harga'],0,',','.')); ?></th>
                                    </tr>ucfirst
                                    <?php ($terbilang = Riskihajar\Terbilang\Facades\Terbilang::make($data['invoice']['total_harga'], ' rupiah')  ?? '' ); ?>
                                    <tr>
                                        <th class="text-left" colspan="<?php echo e($colspan_2); ?>">Terbilang = #   <?php echo e(ucwords($terbilang)); ?> #</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                </div>

                <div class="row" style="padding-top:10px;">
                    <div class="col-12">
                        <table>
                            <tr>
                                <td colspan="3" style="width: 300px; ">Harap Pembayaran Di Transfer Ke</td>
                            </tr>
                            <tr>
                                <td style="width: 300px; ">Bank</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td style="font-weight:bold">OCBC NISP</td>
                            </tr>
                            <tr>
                                <td style="width: 300px; ">A/N</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td  style="font-weight:bold">PT.Sumber Karya Berkah</td>
                            </tr>
                            <tr>
                                <td style="width: 300px; ">No. Rek</td>
                                <td style="width: 2px; padding-right: 10px">:</td>
                                <td  style="font-weight:bold">3308.0000.5911</td>
                            </tr>
                        </table>

                        <table id="ttd" style="margin-top: 20px; margin-left: 15px;">
                            <tr>
                            <td style="min-width: 33%; font-weight: normal; text-align: center">Hormat Kami</td>
                            </tr>
                            <tr>
                            <td style="padding-top: 100px; max-width: 33%; text-align: center; text-transform: uppercase">( _ _ _ _ _ _ _ _ _ _ _ _ _ _ _)</td>
                            </tr>
                      </table>
                    </div>
                </div>

                <!-- end row -->




            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
@media print
{
    @page {
      size: A4; /* DIN A4 standard, Europe */
      margin: 27mm 10mm 27mm 10mm;
    }
    html, body {
        width: 210mm;
        /* height: 282mm; */
        font-size: 10px;
        color: #000;
        background: #FFF;
        overflow:visible;
    }
    body {
        padding-top:15mm;
    }


    #Datatable {
        border: solid #000 !important;
        border-width: 1px 0 0 1px !important;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}



    $(document).ready(function () {
        // $('#tanggal_lahir').datepicker({ dateFormat: "yy-mm-dd" });








    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sumberkah\resources\views/backend/invoice/show.blade.php ENDPATH**/ ?>