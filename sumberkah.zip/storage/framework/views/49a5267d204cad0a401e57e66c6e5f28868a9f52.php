<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="float-end">
                    <a onclick="printDiv('printableArea')" class="btn btn-success me-1"><i class="fa fa-print"></i></a>
                    <a onclick="window.history.back();" class="btn btn-primary w-md">Kembali</a>
                </div>
            </div>
            <div class="card-body" id="printableArea">
                <div class="invoice-title">
                    <h6 class="main-content-label mb-1"><?php echo e($config['page_title'] ?? ''); ?></h6>
                    <div class="mb-4">
                           <img  src="<?php echo e(URL::to('storage/images/logo/'.Setting::get_setting()->icon)); ?>" alt="logo" height="50">
                    </div>
                    <div class="text-muted">
                        <?php echo e(\Carbon\Carbon::parse($data['joborder']['tgl_joborder'])->isoFormat('dddd, D MMMM Y')); ?>

                        
                    </div>
                </div>



                <div class="row" style="padding-top:10px;">
                    <div class="col-6">
                        <div class="table-responsive mt-4">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="">
                                        <th class="text-left">Kode Joborder</th>
                                        <td class="text-left"><?php echo e($data['joborder']['kode_joborder'] ?? ''); ?></td>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Tanggal Joborder</th>
                                        <td class="text-left"><?php echo e($data['joborder']['tgl_joborder'] ?? ''); ?></td>
                                    </tr>

                                    <tr class="">
                                        <th class="text-left">Driver</th>
                                        <td class="text-left"><?php echo e($data['joborder']['driver']['name'] ?? ''); ?></td>
                                    </tr>

                                    <tr class="">
                                        <th class="text-left">Nomor Plat Polisi</th>
                                        <td class="text-left"><?php echo e($data['joborder']['mobil']['nomor_plat'] ?? ''); ?></td>
                                    </tr>

                                    <tr class="">
                                        <th class="text-left">Customer</th>
                                        <td class="text-left"><?php echo e($data['joborder']['customer']['name'] ?? ''); ?></td>
                                    </tr>

                                    <tr class="">
                                        <th class="text-left">Muatan</th>
                                        <td class="text-left"><?php echo e($data['joborder']['muatan']['name'] ?? ''); ?></td>
                                    </tr>


                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="table-responsive mt-4">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="">
                                        <th class="text-left">Alamat Awal (Dari)</th>
                                        <td class="text-left"><?php echo e($data['joborder']['ruteawal']['name'] ?? ''); ?></td>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Alamat Akhir (Ke)</th>
                                        <td class="text-left"><?php echo e($data['joborder']['ruteakhir']['name'] ?? ''); ?></td>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Total Uang Jalan</th>
                                        <td class="text-end">Rp. <?php echo e(number_format($data['joborder']['total_uang_jalan'],0,',','.') ?? '0'); ?></td>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Tambahan/Potongan</th>
                                        <td class="text-end">Rp. <?php echo e(number_format($data['joborder']['biaya_lain'],0,',','.') ?? '0'); ?> <?php echo e(isset($data['joborder']['tambahan_potongan']) ? $data['joborder']['tambahan_potongan'] != 'None' ? '('. $data['joborder']['tambahan_potongan'] . ')' : '' : ''); ?></td>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Total Payment</th>
                                        <td class="text-end">Rp. <?php echo e(number_format($data['joborder']['total_payment'],0,',','.') ?? '0'); ?></td>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Total Kasbon</th>
                                        <td class="text-end">Rp. <?php echo e(number_format($data['joborder']['total_kasbon'],0,',','.') ?? '0'); ?></td>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Sisa Uang Jalan</th>
                                        <td class="text-end">Rp. <?php echo e(number_format($data['joborder']['sisa_uang_jalan'],0,',','.') ?? '0'); ?></td>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="table-responsive mt-4">
                            <table class="table table-bordered">
                                <thead>
                                    <?php if( $data['joborder']['status_payment'] == '2'): ?>
                                        <?php ($class =  'bg-success'); ?>
                                        <?php ($text =  'Lunas'); ?>
                                    <?php elseif( $data['joborder']['status_payment'] == '1'): ?>
                                        <?php ($class =  'bg-warning'); ?>
                                        <?php ($text =  'Progress Payment'); ?>
                                    <?php else: ?>
                                        <?php ($class = 'bg-danger'); ?>
                                        <?php ($text =  'Belum Bayar'); ?>
                                    <?php endif; ?>
                                    <tr class="">
                                        <th class="text-left">Status Pembayaran</th>
                                        <th class="text-left"><span class="badge bg-pill <?php echo e($class); ?>"><?php echo e($text); ?></span> </th>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Pembuat Joborder</th>
                                        <th class="text-left"><?php echo e($data['joborder']['createdby']['name'] ?? ''); ?>  <?php echo e($data['joborder']['created_at'] ?? ''); ?> </th>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Penutup Joborder</th>
                                        <th class="text-left"><?php echo e($data['joborder']['konfirmasijo'][0]['createdby']['name'] ?? ''); ?>  <?php echo e($data['joborder']['konfirmasijo'][0]['created_at'] ?? ''); ?> </th>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Pembuat Slip Gaji</th>
                                        <th class="text-left"><?php echo e($data['joborder']['gaji']['createdby']['name'] ?? ''); ?>  <?php echo e($data['joborder']['gaji']['created_at'] ?? ''); ?> </th>
                                    </tr>
                                    <tr class="">
                                        <th class="text-left">Pembuat Invoice</th>
                                        <th class="text-left"><?php echo e($data['joborder']['invoice']['createdby']['name'] ?? ''); ?>  <?php echo e($data['joborder']['invoice']['created_at'] ?? ''); ?> </th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>






                <div class="row" style="padding-top:10px;">
                    <h6 class="main-content-label mb-1">Pembayaran</h6>
                    <div class="col-12">
                        <div class="table-responsive">
                            <table id="Datatable" class="table table-bordered border-bottom w-100" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Jenis Payment</th>
                                        <th>Keterangan</th>
                                        <th>Keterangan Kasbon</th>
                                        <th>Nominal</th>
                                        <th>Nominal Kasbon</th>
                                      </tr>
                                </thead>
                                <tbody>
                                    <?php ($total_cicilan =  0); ?>
                                    <?php $__currentLoopData = $data['joborder']['payment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($val->jenis_payment); ?></td>
                                            <td><?php echo e($val->keterangan); ?></td>
                                            <td><?php echo e($val->keterangan_kasbon); ?></td>

                                            <td class="text-end"> Rp. <?php echo e(number_format($val->nominal,0,',','.')); ?></td>
                                            <td class="text-end"> Rp. <?php echo e(number_format($val->nominal_kasbon,0,',','.')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th class="text-end" colspan="3">Total Payment</th>
                                        <th class="text-end">Rp. <?php echo e(number_format($data['joborder']['payment']->SUM('nominal'),0,',','.')); ?></th>
                                        <th class="text-end">Rp. <?php echo e(number_format($data['joborder']['payment']->SUM('nominal_kasbon'),0,',','.')); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                </div>
                <!-- end row -->


                <div class="row" style="padding-top:10px;">
                    <div class="col-12">
                        <label for="select2Merk">Keterangan<span class="text-danger">*</span></label>
                        <textarea class="form-control"><?php echo e($data['joborder']['keterangan_joborder'] ?? ''); ?></textarea>
                    </div>

                </div>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
@media print
{
    @page {
      size: A4; /* DIN A4 standard, Europe */
      margin: 27mm 16mm 27mm 16mm;
    }
    html, body {
        width: 210mm;
        /* height: 297mm; */
        height: 282mm;
        font-size: 16px;
        color: #000;
        background: #FFF;
        overflow:visible;
    }
    body {
        padding-top:15mm;
    }
    table {
        border: solid #000 !important;
        border-width: 1px 0 0 1px !important;
    }
    th, td {
        border: solid #000 !important;
        border-width: 0 1px 1px 0 !important;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}



    $(document).ready(function () {
        // $('#tanggal_lahir').datepicker({ dateFormat: "yy-mm-dd" });








    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sumberkah\resources\views/backend/joborder/show.blade.php ENDPATH**/ ?>