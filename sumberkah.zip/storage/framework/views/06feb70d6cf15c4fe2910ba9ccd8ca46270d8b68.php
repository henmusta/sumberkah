<!doctype html>
<html lang="en">
<!-- Mirrored from themesbrand.com/borex/layouts/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 30 Dec 2022 12:49:54 GMT -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo e(Setting::get_setting()->name); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/backend/images/favicon.ico')); ?>">

        <?php echo $__env->make('backend.layouts.headercss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <style>
            .select2-selection__rendered {
                line-height: 35px !important;
            }
            .select2-container .select2-selection--single {
                height: 35px !important;
            }
            .select2-selection__arrow {
                height: 35px !important;
            }

            .select2-container--default .select2-selection--single .select2-selection__clear {

                height: 35px !important;

            }

            .select2-container .select2-selection--single .select2-selection__rendered {
                padding-left: 15px !important;
            }
        </style>
    </head>


    <body data-layout="<?php echo e(Setting::get_setting()->layout); ?>"
        data-topbar="<?php echo e(Setting::get_setting()->topbar_color); ?>"
        data-sidebar="<?php echo e(Setting::get_setting()->sidebar_color); ?>"
        data-layout-mode="<?php echo e(Setting::get_setting()->layout_mode); ?>"
        data-layout-scrollable="<?php echo e(Setting::get_setting()->layout_position == 'fixed' ? 'false' : 'true'); ?>"
        data-layout-size="<?php echo e(Setting::get_setting()->layout_width); ?>"
        data-sidebar-size="<?php echo e(Setting::get_setting()->sidebar_size); ?>">

        <div id="layout-wrapper">


            <?php echo $__env->make('backend.layouts.headervertical', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">
                <?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- Left Sidebar End -->
            <?php echo $__env->make('backend.layouts.headerhorizontal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
                <!-- End Page-content -->


            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->





        <!-- chat offcanvas -->
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasActivity" aria-labelledby="offcanvasActivityLabel">
            <div class="offcanvas-header border-bottom">
              <h5 id="offcanvasActivityLabel">Offcanvas right</h5>
              <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
              ...
            </div>
        </div>

        <!-- JAVASCRIPT -->
        <?php echo $__env->make('backend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('backend.layouts.footerjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>


<!-- Mirrored from themesbrand.com/borex/layouts/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 30 Dec 2022 12:49:54 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\sumberkah\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>