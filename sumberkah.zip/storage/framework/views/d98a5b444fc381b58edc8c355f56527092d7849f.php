<nav aria-label="breadcrumb">
<ol class="breadcrumb">
  <?php $__currentLoopData = $page_breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($loop->last): ?>
      <?php
        $active = ' active';
      ?>
    <?php endif; ?>
    <li style="font-size:18px; font-weight:bold;" class="breadcrumb-item<?php echo e($active ?? ""); ?>  <?php echo e(isset($active) ? "aria-current='page'" : ''); ?>">
      <?php if(!$loop->last): ?>
        <a href=<?php echo e($item['url'] ?? "#"); ?>><?php echo e($item['title'] ?? ''); ?></a>
      <?php else: ?>
        <?php echo e($item['title' ?? '']); ?>

      <?php endif; ?>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ol>

</nav>

<!-- END : Breadcrumb -->



<?php /**PATH C:\xampp\htdocs\sumberkah\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>