        <!-- JAVASCRIPT -->
        <script src="<?php echo e(asset('assets/backend/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/metismenujs/metismenujs.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/eva-icons/eva.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/js/app.js')); ?>"></script>

        

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
        <script src="https://cdn.datatables.net/responsive/2.4.0/js/dataTables.responsive.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr@latest/dist/plugins/monthSelect/index.js"></script>

        <script src="<?php echo e(asset('assets/backend/vendor_components/autoNumeric/autonumeric.js')); ?>"></script>



<script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/vendor_components/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/vendor_components/pdfmake/build/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/vendor_components/pdfmake/build/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>


        <?php echo $__env->yieldContent('script'); ?>
<?php /**PATH C:\xampp\htdocs\sumberkah\resources\views/backend/layouts/footerjs.blade.php ENDPATH**/ ?>